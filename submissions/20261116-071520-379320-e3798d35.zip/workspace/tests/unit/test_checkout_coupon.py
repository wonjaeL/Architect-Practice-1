from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime, timedelta

import pytest

from parkfee.application.checkout import CheckoutService
from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.domain.season_pass import SeasonPass
from parkfee.domain.vehicle import VehicleType
from parkfee.pricing.schedule import PricingConfig
from tests.conftest import FakeSeasonPassRepository, SessionFactory


@pytest.fixture
def service(pricing_config: PricingConfig) -> CheckoutService:
    return CheckoutService(pricing_config, FakeSeasonPassRepository())


@pytest.fixture
def coupon() -> Coupon:
    return Coupon(
        code="TEST-COUPON",
        kind=CouponKind.TIME,
        value=60,
        lot_id="HJ-02",
        partner="제휴 매장",
        valid_from=datetime(2026, 9, 1),
        valid_until=datetime(2026, 9, 30, 23, 59, 59),
    )


@pytest.mark.parametrize(
    ("lot_id", "minutes", "value", "expected", "status"),
    [
        ("HJ-02", 660, 120, 27000, "applied"),
        ("HJ-02", 60, 60, 0, "applied"),
        ("HJ-02", 60, 120, 0, "applied"),
        ("HJ-02", 16, 1, 1500, "unused"),
        ("HJ-02", 90, 60, 1500, "applied"),
        ("HJ-02", 91, 60, 2000, "applied"),
        ("HJ-02", 100, 60, 2000, "applied"),
        ("HJ-02", 101, 60, 2500, "applied"),
        ("HJ-01", 1441, 1, 25000, "applied"),
        ("HJ-01", 1442, 1, 27000, "unused"),
        ("HJ-03", 1441, 1, 6000, "applied"),
        ("HJ-03", 1442, 1, 12000, "unused"),
    ],
)
def test_time_coupon_recalculates_charge(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    lot_id: str,
    minutes: int,
    value: int,
    expected: int,
    status: str,
) -> None:
    """할인·감면 규정 제13·16조: 시간을 먼저 차감하며 회차는 실제 시간 기준이다."""
    session = make_session(minutes, lot_id=lot_id)
    receipt = service.checkout(session, replace(coupon, lot_id=lot_id, value=value))
    assert receipt.total == Money(expected)
    assert receipt.coupon is not None
    assert receipt.coupon.status == status
    assert receipt.parked_minutes == minutes
    assert receipt.charge == service.checkout(session).charge
    assert not receipt.grace_applied
    assert receipt.vat_supply + receipt.vat_tax == receipt.total


@pytest.mark.parametrize(("minutes", "value", "expected"), [(660, 1000, 29000), (120, 9999, 0)])
def test_amount_coupon_after_daily_max_with_zero_floor(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    minutes: int,
    value: int,
    expected: int,
) -> None:
    """할인·감면 규정 제14조: 일 최대 적용 후 금액 차감, 0원 하한."""
    receipt = service.checkout(
        make_session(minutes, lot_id="HJ-02"),
        replace(coupon, kind=CouponKind.AMOUNT, value=value),
    )
    assert receipt.total == Money(expected)
    assert receipt.coupon is not None and receipt.coupon.status == "applied"
    assert receipt.discount_total == receipt.charge.minus(Money(expected))


@pytest.mark.parametrize(
    ("kind", "value", "is_compact", "expected", "status"),
    [
        (CouponKind.AMOUNT, 1000, True, 3700, "unused"),
        (CouponKind.TIME, 60, False, 3000, "applied"),
        (CouponKind.AMOUNT, 600, False, 5400, "unused"),
        (CouponKind.AMOUNT, 2250, True, 3700, "unused"),
        (CouponKind.AMOUNT, 2301, True, 3600, "applied"),
    ],
)
def test_compare_separate_paths_after_rounding(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    kind: CouponKind,
    value: int,
    is_compact: bool,
    expected: int,
    status: str,
) -> None:
    """할인·감면 규정 제15조: 규정 계산 예와 절사 후 동률 반환(3,750 대 3,780)."""
    session = make_session(
        120,
        lot_id="HJ-02",
        is_member=True,
        vehicle_type=VehicleType.COMPACT if is_compact else VehicleType.GENERAL,
    )
    receipt = service.checkout(session, replace(coupon, kind=kind, value=value))
    assert receipt.total == Money(expected)
    assert receipt.coupon is not None and receipt.coupon.status == status
    kinds = [discount.kind.value for discount in receipt.discounts]
    if status == "applied":
        assert kinds == ["coupon"]
        expected_discount = Money(value) if kind is CouponKind.AMOUNT else Money(3000)
        assert receipt.discount_total == expected_discount
    else:
        assert "membership" in kinds
        assert "coupon" not in kinds


@pytest.mark.parametrize(
    ("offset", "status"), [(-1, "unused"), (0, "applied"), (3600, "applied"), (3601, "expired")]
)
def test_validity_uses_exit_and_includes_endpoints(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    offset: int,
    status: str,
) -> None:
    """할인·감면 규정 제17조: 출차 시각 기준이며 시작·종료 시각을 포함한다."""
    start = datetime(2026, 9, 15, 9)
    coupon = replace(coupon, valid_from=start, valid_until=start + timedelta(hours=1))
    exit_at = start + timedelta(seconds=offset)
    session = make_session(120, lot_id="HJ-02", entry_at=exit_at - timedelta(hours=2))
    receipt = service.checkout(session, coupon)
    assert receipt.coupon is not None and receipt.coupon.status == status
    assert receipt.total == Money(3000 if status == "applied" else 6000)


def test_coupon_expiring_during_parking(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
) -> None:
    """할인·감면 규정 제17조4항: 입차 때 유효해도 다음 날 출차 때 만료면 적용하지 않는다."""
    coupon = replace(coupon, valid_until=datetime(2026, 9, 10, 23, 59, 59))
    session = make_session(180, lot_id="HJ-02", entry_at=datetime(2026, 9, 10, 22))
    receipt = service.checkout(session, coupon)
    assert receipt.coupon is not None and receipt.coupon.status == "expired"
    assert receipt.total == service.checkout(session).total


def test_other_lot_returns_coupon(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
) -> None:
    """할인·감면 규정 제12조: 다른 주차장 쿠폰은 반환한다."""
    receipt = service.checkout(make_session(120), coupon)
    assert receipt.coupon is not None and receipt.coupon.status == "unused"
    assert receipt.total == Money(6500)


@pytest.mark.parametrize("has_season_pass", [False, True])
@pytest.mark.parametrize("is_expired", [False, True])
def test_free_exit_returns_coupon(
    pricing_config: PricingConfig,
    make_session: SessionFactory,
    coupon: Coupon,
    has_season_pass: bool,
    is_expired: bool,
) -> None:
    """할인·감면 규정 제16·18조: 회차·정기권 무료 출차는 쿠폰을 반환한다."""
    passes = [SeasonPass("12가3456", "HJ-02", date(2026, 9, 1), date(2026, 9, 30))]
    service = CheckoutService(
        pricing_config, FakeSeasonPassRepository(passes if has_season_pass else [])
    )
    if is_expired:
        coupon = replace(coupon, valid_until=datetime(2026, 8, 31))
    receipt = service.checkout(make_session(120 if has_season_pass else 15, lot_id="HJ-02"), coupon)
    assert receipt.coupon is not None and receipt.coupon.status == "unused"
    assert receipt.coupon.code == coupon.code
    assert receipt.total == Money.zero()
    assert receipt.season_pass_applied == has_season_pass
    assert receipt.grace_applied == (not has_season_pass)
