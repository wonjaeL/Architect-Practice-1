from __future__ import annotations

from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.pricing.charge import create_charge_strategy
from parkfee.pricing.schedule import Schedule


class CouponChargePolicy:
    """쿠폰만 적용한 절사 전 금액(할인·감면 규정 제13·14조)."""

    def charge(self, coupon: Coupon, minutes: int, schedule: Schedule, charge: Money) -> Money:
        if coupon.kind is CouponKind.TIME:
            remaining_minutes = max(0, minutes - coupon.value)
            return create_charge_strategy(schedule).charge(remaining_minutes)
        return charge.minus(Money(coupon.value))
