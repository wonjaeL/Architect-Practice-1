from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime, timedelta

import pytest

from parkfee.application.checkout import CheckoutService
from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.domain.season_pass import SeasonPass
from parkfee.domain.vehicle import VehicleType
from parkfee.pricing.schedule import PricingConfig
from tests.conftest import FakeSeasonPassRepository, SessionFactory

ENTRY = datetime(2026, 9, 15, 9)
COUPON = Coupon(
    code="TEST-COUPON",
    kind=CouponKind.TIME,
    value=60,
    lot_id="HJ-02",
    partner="제휴 매장",
    valid_from=datetime(2026, 9, 15),
    valid_until=datetime(2026, 9, 30, 23, 59, 59),
)


@pytest.fixture
def service(pricing_config: PricingConfig) -> CheckoutService:
    return CheckoutService(pricing_config, FakeSeasonPassRepository())


@pytest.mark.parametrize(
    ("lot_id", "minutes", "value", "expected"),
    [
        ("HJ-02", 660, 120, 27000),
        ("HJ-02", 60, 60, 0),
        ("HJ-02", 60, 120, 0),
        ("HJ-02", 75, 60, 1500),
        ("HJ-02", 90, 60, 1500),
        ("HJ-02", 91, 60, 2000),
        ("HJ-02", 100, 60, 2000),
        ("HJ-02", 101, 60, 2500),
        ("HJ-01", 1441, 1, 25000),
        ("HJ-01", 1501, 60, 27000),
        ("HJ-03", 1441, 1, 6000),
        ("HJ-03", 60, 60, 0),
    ],
)
def test_time_coupon_recalculates_charge(
    service: CheckoutService,
    make_session: SessionFactory,
    lot_id: str,
    minutes: int,
    value: int,
    expected: int,
) -> None:
    """할인·감면 제13·16조: 시간부터 차감하고 요금 제6~8조 적용, 회차 재판정 금지."""
    session = make_session(minutes, lot_id=lot_id, entry_at=ENTRY)
    coupon = replace(COUPON, lot_id=lot_id, value=value)
    original = service.checkout(session)
    receipt = service.checkout(session, coupon)
    assert receipt.total == Money(expected)
    assert receipt.charge == original.charge
    assert receipt.parked_minutes == minutes
    assert not receipt.grace_applied
    assert receipt.coupon is not None
    status = "applied" if receipt.total < original.total else "unused"
    assert receipt.coupon.status.value == status
    assert receipt.vat_supply + receipt.vat_tax == receipt.total
    if status == "applied":
        assert [discount.kind.value for discount in receipt.discounts] == ["coupon"]
        assert receipt.discount_total == receipt.charge.minus(receipt.total)


@pytest.mark.parametrize(("value", "expected"), [(1000, 29000), (35000, 0)])
def test_amount_coupon_after_daily_max(
    service: CheckoutService, make_session: SessionFactory, value: int, expected: int
) -> None:
    """할인·감면 제14조: 일 최대 적용 후 금액 차감, 0원 하한."""
    coupon = replace(COUPON, kind=CouponKind.AMOUNT, value=value)
    receipt = service.checkout(make_session(660, lot_id="HJ-02", entry_at=ENTRY), coupon)
    assert receipt.charge == Money(30000)
    assert receipt.total == Money(expected)
    assert receipt.coupon is not None
    assert receipt.coupon.status.value == "applied"


@pytest.mark.parametrize(
    ("kind", "value", "vehicle_type", "expected", "status", "discount_types"),
    [
        (CouponKind.AMOUNT, 1000, VehicleType.COMPACT, 3700, "unused", ["reduction", "membership"]),
        (CouponKind.TIME, 60, VehicleType.GENERAL, 3000, "applied", ["coupon"]),
        (CouponKind.AMOUNT, 2220, VehicleType.COMPACT, 3700, "unused", ["reduction", "membership"]),
        (CouponKind.AMOUNT, 2250, VehicleType.COMPACT, 3700, "unused", ["reduction", "membership"]),
        (CouponKind.AMOUNT, 2301, VehicleType.COMPACT, 3600, "applied", ["coupon"]),
    ],
)
def test_choose_lower_rounded_total_and_return_coupon_on_tie(
    service: CheckoutService,
    make_session: SessionFactory,
    kind: CouponKind,
    value: int,
    vehicle_type: VehicleType,
    expected: int,
    status: str,
    discount_types: list[str],
) -> None:
    """할인·감면 제15조: 규정 계산 예, 절사 후 비교 및 동액 반환, 중복 적용 금지."""
    session = make_session(
        120, lot_id="HJ-02", entry_at=ENTRY, vehicle_type=vehicle_type, is_member=True
    )
    receipt = service.checkout(session, replace(COUPON, kind=kind, value=value))
    assert receipt.total == Money(expected)
    assert receipt.coupon is not None
    assert receipt.coupon.code == COUPON.code
    assert receipt.coupon.status.value == status
    assert [discount.kind.value for discount in receipt.discounts] == discount_types
    assert receipt.vat_supply + receipt.vat_tax == receipt.total
    if status == "applied" and kind is CouponKind.AMOUNT:
        assert receipt.discount_total == Money(value)


@pytest.mark.parametrize(
    ("start_offset", "end_offset", "status"),
    [(0, 1, "applied"), (-1, 0, "applied"), (1, 2, "unused"), (-7200, -1, "expired")],
)
def test_validity_uses_exit_with_inclusive_endpoints(
    service: CheckoutService,
    make_session: SessionFactory,
    start_offset: int,
    end_offset: int,
    status: str,
) -> None:
    """할인·감면 제17조: 출차 기준, 양 끝 포함, 시작 전 반환, 만료 시 일반 할인."""
    session = make_session(120, lot_id="HJ-02", entry_at=ENTRY, is_member=True)
    coupon = replace(
        COUPON,
        valid_from=session.exit_at + timedelta(seconds=start_offset),
        valid_until=session.exit_at + timedelta(seconds=end_offset),
    )
    receipt = service.checkout(session, coupon)
    assert receipt.coupon is not None
    assert receipt.coupon.status.value == status
    assert receipt.total == Money(3000 if status == "applied" else 5400)


def test_expired_coupon_across_midnight(
    service: CheckoutService, make_session: SessionFactory
) -> None:
    """할인·감면 제17조 계산 예: 입차 때 유효해도 출차 전에 만료되면 적용하지 않는다."""
    coupon = replace(
        COUPON,
        valid_from=datetime(2026, 9, 1),
        valid_until=datetime(2026, 9, 10, 23, 59, 59),
    )
    session = make_session(180, lot_id="HJ-02", entry_at=datetime(2026, 9, 10, 22))
    receipt = service.checkout(session, coupon)
    assert receipt.total == Money(9000)
    assert receipt.coupon is not None
    assert receipt.coupon.status.value == "expired"


def test_other_lot_coupon_is_returned(
    service: CheckoutService, make_session: SessionFactory
) -> None:
    """할인·감면 제12조: 발급 주차장이 다르면 반환하고 일반 할인 적용."""
    receipt = service.checkout(make_session(120, entry_at=ENTRY, is_member=True), COUPON)
    assert receipt.total == Money(5800)
    assert receipt.coupon is not None
    assert receipt.coupon.status.value == "unused"


@pytest.mark.parametrize(("lot_id", "grace"), [("HJ-01", 10), ("HJ-02", 15)])
@pytest.mark.parametrize("is_expired", [False, True])
def test_grace_returns_coupon(
    service: CheckoutService,
    make_session: SessionFactory,
    lot_id: str,
    grace: int,
    is_expired: bool,
) -> None:
    """할인·감면 제16조: 실제 주차 시간으로 회차 판단, 쿠폰 반환."""
    coupon = replace(COUPON, lot_id=lot_id)
    if is_expired:
        coupon = replace(coupon, valid_until=ENTRY)
    receipt = service.checkout(make_session(grace, lot_id=lot_id, entry_at=ENTRY), coupon)
    assert receipt.grace_applied
    assert receipt.total == Money.zero()
    assert receipt.coupon is not None
    assert receipt.coupon.status.value == "unused"


@pytest.mark.parametrize("is_expired", [False, True])
def test_season_pass_returns_coupon(
    pricing_config: PricingConfig, make_session: SessionFactory, is_expired: bool
) -> None:
    """할인·감면 제18조: 정기권 무료 출차에서는 쿠폰 반환."""
    passes = FakeSeasonPassRepository(
        [SeasonPass("12가3456", "HJ-02", date(2026, 9, 1), date(2026, 9, 30))]
    )
    service = CheckoutService(pricing_config, passes)
    coupon = replace(COUPON, valid_until=ENTRY) if is_expired else COUPON
    receipt = service.checkout(make_session(120, lot_id="HJ-02", entry_at=ENTRY), coupon)
    assert receipt.season_pass_applied
    assert receipt.total == Money.zero()
    assert receipt.coupon is not None
    assert receipt.coupon.status.value == "unused"
