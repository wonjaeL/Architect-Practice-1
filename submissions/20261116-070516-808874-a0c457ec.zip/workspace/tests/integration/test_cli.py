"""CLI 통합 테스트(docs/api/cli.md). 실제 data/ 복사본으로 명령을 실행한다."""

from __future__ import annotations

import json
import runpy
import sys

import pytest

from parkfee.infrastructure.data_dir import DataDirectory
from parkfee.presentation.cli import main
from tests.conftest import REPO_ROOT

SAMPLE_CSV = str(REPO_ROOT / "data" / "samples" / "sessions_2026-09-01.csv")


def _calc_args(data_dir: DataDirectory, *extra: str) -> list[str]:
    return [
        "--data-dir",
        str(data_dir.root),
        "calc",
        "--lot",
        "HJ-01",
        "--plate",
        "12가3456",
        "--entry",
        "2026-09-01T09:00",
        "--exit",
        "2026-09-01T11:05",
        *extra,
    ]


def test_calc_text(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(_calc_args(data_dir, "--vehicle-type", "compact", "--member")) == 0
    assert "결제금액 : 4,400원" in capsys.readouterr().out


def test_calc_json(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(_calc_args(data_dir, "--format", "json")) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["total"] == 7000


def test_calc_season_pass_from_data_file(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    args = _calc_args(data_dir, "--format", "json")
    args[args.index("12가3456")] = "34나5678"
    assert main(args) == 0
    assert json.loads(capsys.readouterr().out)["season_pass"] is True


def test_batch_report(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--data-dir", str(data_dir.root), "batch", SAMPLE_CSV, "--format", "json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["total_sessions"] == 16
    assert payload["total_revenue"] == 79900


def test_coupon_show(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", "HJM-2609-0002"]) == 0
    assert "한결마트 무료 주차 120분" in capsys.readouterr().out


def test_data_dir_from_environment(
    data_dir: DataDirectory,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("PARKFEE_DATA_DIR", str(data_dir.root))
    assert main(["coupon", "show", "HJT-2609-0001", "--format", "json"]) == 0
    assert json.loads(capsys.readouterr().out)["lot_id"] == "HJ-01"


@pytest.mark.parametrize(
    ("replace", "code"),
    [(("HJ-01", "HJ-99"), "E1003"), (("2026-09-01T11:05", "11시"), "E1002")],
)
def test_input_errors_exit_with_3(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    replace: tuple[str, str],
    code: str,
) -> None:
    args = _calc_args(data_dir)
    args[args.index(replace[0])] = replace[1]
    assert main(args) == 3
    assert code in capsys.readouterr().err


def test_unknown_coupon_exits_with_3(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", "NOPE"]) == 3
    assert "E2001" in capsys.readouterr().err


def test_missing_data_dir_exits_with_4(capsys: pytest.CaptureFixture[str]) -> None:
    args = ["--data-dir", "/nonexistent", "calc", "--lot", "HJ-01", "--plate", "1가1111"]
    args += ["--entry", "2026-09-01T09:00", "--exit", "2026-09-01T10:00"]
    assert main(args) == 4
    assert "E3001" in capsys.readouterr().err


def test_version_option(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exit_info:
        main(["--version"])
    assert exit_info.value.code == 0
    assert "parkfee 1.6.0" in capsys.readouterr().out


def test_module_entry_point(
    data_dir: DataDirectory,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        ["parkfee", "--data-dir", str(data_dir.root), "coupon", "show", "HJM-2609-0001"],
    )
    with pytest.raises(SystemExit) as exit_info:
        runpy.run_module("parkfee", run_name="__main__")
    assert exit_info.value.code == 0
    assert "한결시네마" in capsys.readouterr().out


@pytest.mark.parametrize(
    ("code", "status", "label", "total"),
    [
        ("HJT-2609-0001", "applied", "사용", 5500),
        ("HJM-2609-0001", "unused", "반환", 7000),
        ("HJT-2609-0002", "unused", "반환", 7000),
        ("HJM-2608-0107", "expired", "만료", 7000),
    ],
)
@pytest.mark.parametrize("output_format", ["json", "text"])
def test_calc_coupon_receipt(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    code: str,
    status: str,
    label: str,
    total: int,
    output_format: str,
) -> None:
    """할인·감면 제19조: 쿠폰 코드와 처리 결과를 두 출력 형식에 표시."""
    assert main(_calc_args(data_dir, "--coupon", code, "--format", output_format)) == 0
    output = capsys.readouterr().out
    if output_format == "json":
        payload = json.loads(output)
        assert payload["coupon"] == {"code": code, "status": status}
        assert payload["total"] == total
    else:
        assert f"쿠폰     : {code} ({label})" in output
        assert f"결제금액 : {total:,}원" in output


def test_calc_without_coupon_does_not_read_coupon_file(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    """ISSUE-142: 미지정 시 coupon=null, 기존 정산은 쿠폰 파일에 의존하지 않는다."""
    data_dir.coupons.unlink()
    assert main(_calc_args(data_dir, "--format", "json")) == 0
    assert json.loads(capsys.readouterr().out)["coupon"] is None


@pytest.mark.parametrize("plate", ["12가3456", "34나5678"])
def test_calc_unknown_coupon_matches_show_error(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str], plate: str
) -> None:
    """ISSUE-142: 정기권 차량도 없는 코드는 coupon show와 같은 E2001 오류."""
    assert main(_calc_args(data_dir, "--plate", plate, "--coupon", "NOPE")) == 3
    result = capsys.readouterr()
    assert result.out == ""
    assert "E2001" in result.err
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", "NOPE"]) == 3
    assert capsys.readouterr().err == result.err


def test_calc_reads_coupon_from_selected_data_dir(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    """ISSUE-142: --data-dir에 저장된 쿠폰 값으로 계산한다."""
    records = json.loads(data_dir.coupons.read_text(encoding="utf-8"))
    records[-2]["value"] = 120
    data_dir.coupons.write_text(json.dumps(records), encoding="utf-8")
    assert main(_calc_args(data_dir, "--coupon", "HJT-2609-0001", "--format", "json")) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["total"] == 2000
    assert payload["coupon"]["status"] == "applied"


@pytest.mark.parametrize("is_missing", [False, True])
def test_calc_bad_coupon_file_exits_with_4(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str], is_missing: bool
) -> None:
    """ISSUE-142: 쿠폰 파일 오류는 기존 E3001 / 종료 코드 4를 유지한다."""
    if is_missing:
        data_dir.coupons.unlink()
    else:
        data_dir.coupons.write_text("{", encoding="utf-8")
    assert main(_calc_args(data_dir, "--coupon", "HJT-2609-0001")) == 4
    assert "E3001" in capsys.readouterr().err
