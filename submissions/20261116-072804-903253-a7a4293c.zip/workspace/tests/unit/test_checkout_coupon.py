"""쿠폰 정산: 할인·감면 규정 제5장, 요금 규정 제5~11조."""

from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime, timedelta

import pytest

from parkfee.application.checkout import CheckoutService
from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.domain.receipt import CouponStatus, DiscountKind
from parkfee.domain.season_pass import SeasonPass
from parkfee.domain.vehicle import VehicleType
from parkfee.pricing.schedule import PricingConfig
from tests.conftest import FakeSeasonPassRepository, SessionFactory


@pytest.fixture
def service(pricing_config: PricingConfig) -> CheckoutService:
    return CheckoutService(pricing_config, FakeSeasonPassRepository())


@pytest.fixture
def coupon() -> Coupon:
    return Coupon(
        code="TEST-COUPON",
        kind=CouponKind.TIME,
        value=120,
        lot_id="HJ-02",
        partner="테스트 매장",
        valid_from=datetime(2026, 9, 1),
        valid_until=datetime(2026, 9, 30, 23, 59, 59),
    )


def test_time_coupon_precedes_daily_cap(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제13조 예: 660분 - 120분 = 540분, 27,000원 (24,000원이 아님)."""
    receipt = service.checkout(make_session(660, lot_id="HJ-02"), coupon)
    assert receipt.charge == Money(30000)
    assert receipt.total == Money(27000)
    assert receipt.parked_minutes == 660
    assert receipt.discount_total == Money(3000)
    assert [item.kind for item in receipt.discounts] == [DiscountKind.COUPON]
    assert (receipt.vat_supply, receipt.vat_tax) == (Money(24545), Money(2455))
    assert receipt.coupon is not None
    assert receipt.coupon.code == coupon.code
    assert receipt.coupon.status is CouponStatus.APPLIED


@pytest.mark.parametrize(
    ("minutes", "value", "expected"),
    [
        (60, 60, 0),
        (60, 120, 0),
        (16, 1, 1500),
        (120, 90, 1500),
        (120, 89, 2000),
        (120, 80, 2000),
        (120, 79, 2500),
        (1441, 1, 30000),
        (1442, 1, 31500),
    ],
)
def test_time_coupon_boundaries(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    minutes: int,
    value: int,
    expected: int,
) -> None:
    """제13·16조: 차감 후 0분, 기본·단위·24시간 경계, 회차는 실제 시간 기준."""
    receipt = service.checkout(make_session(minutes, lot_id="HJ-02"), replace(coupon, value=value))
    assert receipt.total == Money(expected)
    assert not receipt.grace_applied


@pytest.mark.parametrize(("value", "expected"), [(1000, 29000), (40000, 0)])
def test_amount_coupon_after_daily_cap(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    value: int,
    expected: int,
) -> None:
    """제14조: 일 최대 요금에서 금액을 차감하고 0원 하한을 적용한다."""
    receipt = service.checkout(
        make_session(660, lot_id="HJ-02"),
        replace(coupon, kind=CouponKind.AMOUNT, value=value),
    )
    assert receipt.total == Money(expected)
    assert receipt.discount_total == Money(30000 - expected)


@pytest.mark.parametrize(("minutes", "expected"), [(1441, 6000), (1442, 12000)])
def test_time_coupon_with_daily_flat_schedule(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    minutes: int,
    expected: int,
) -> None:
    """제13조·요금 규정 제8조: 정액제도 남은 시간으로 24시간 구간을 계산한다."""
    receipt = service.checkout(
        make_session(minutes, lot_id="HJ-03"), replace(coupon, lot_id="HJ-03", value=1)
    )
    assert receipt.total == Money(expected)


def test_better_reduction_and_membership_returns_coupon(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제15조 예: 쿠폰 5,000원보다 감면·멤버십 3,700원이 유리하다."""
    session = make_session(120, lot_id="HJ-02", vehicle_type=VehicleType.COMPACT, is_member=True)
    receipt = service.checkout(session, replace(coupon, kind=CouponKind.AMOUNT, value=1000))
    assert receipt.total == Money(3700)
    assert [item.kind for item in receipt.discounts] == [
        DiscountKind.REDUCTION,
        DiscountKind.MEMBERSHIP,
    ]
    assert receipt.coupon is not None
    assert receipt.coupon.status is CouponStatus.UNUSED


def test_better_coupon_does_not_stack_membership(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제15조 예: 멤버십 5,400원 대신 시간 쿠폰만 적용한 3,000원으로 정산한다."""
    receipt = service.checkout(
        make_session(120, lot_id="HJ-02", is_member=True), replace(coupon, value=60)
    )
    assert receipt.total == Money(3000)
    assert [item.kind for item in receipt.discounts] == [DiscountKind.COUPON]
    assert receipt.coupon is not None
    assert receipt.coupon.status is CouponStatus.APPLIED


@pytest.mark.parametrize("value", [1800, 1801])
def test_exact_tie_and_one_rounding_unit_advantage(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon, value: int
) -> None:
    """제15조: 4,200원 동률이면 반환, 4,199원은 절사 후 4,100원으로 사용한다."""
    receipt = service.checkout(
        make_session(120, lot_id="HJ-02", vehicle_type=VehicleType.COMPACT),
        replace(coupon, kind=CouponKind.AMOUNT, value=value),
    )
    assert receipt.total == Money(4200 if value == 1800 else 4100)
    assert receipt.coupon is not None
    assert receipt.coupon.status is (CouponStatus.UNUSED if value == 1800 else CouponStatus.APPLIED)


def test_rounding_can_turn_coupon_advantage_into_tie(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제15조: 3,750원 쿠폰 경로와 3,780원 일반 할인은 모두 3,700원이 된다."""
    receipt = service.checkout(
        make_session(120, lot_id="HJ-02", vehicle_type=VehicleType.COMPACT, is_member=True),
        replace(coupon, kind=CouponKind.AMOUNT, value=2250),
    )
    assert receipt.total == Money(3700)
    assert receipt.coupon is not None
    assert receipt.coupon.status is CouponStatus.UNUSED
    assert receipt.discount_total == Money(2220)


def test_wrong_lot_returns_coupon(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제12조: 발급 주차장 밖에서는 쿠폰을 사용하지 않는다."""
    receipt = service.checkout(make_session(120), coupon)
    assert receipt.total == Money(6500)
    assert receipt.coupon is not None
    assert receipt.coupon.status is CouponStatus.UNUSED


@pytest.mark.parametrize(
    ("exit_at", "status"),
    [
        (datetime(2026, 9, 15, 8, 59, 59), CouponStatus.UNUSED),
        (datetime(2026, 9, 15, 9), CouponStatus.APPLIED),
        (datetime(2026, 9, 15, 18), CouponStatus.APPLIED),
        (datetime(2026, 9, 15, 18, 0, 1), CouponStatus.EXPIRED),
    ],
)
def test_validity_uses_exit_and_includes_endpoints(
    service: CheckoutService,
    make_session: SessionFactory,
    coupon: Coupon,
    exit_at: datetime,
    status: CouponStatus,
) -> None:
    """제17조: 출차 시각으로 판단하고 시작·종료 시각을 포함한다."""
    coupon = replace(
        coupon, valid_from=datetime(2026, 9, 15, 9), valid_until=datetime(2026, 9, 15, 18)
    )
    session = make_session(120, lot_id="HJ-02", entry_at=exit_at - timedelta(minutes=120))
    receipt = service.checkout(session, coupon)
    assert receipt.coupon is not None
    assert receipt.coupon.status is status
    assert receipt.total == (Money.zero() if status is CouponStatus.APPLIED else Money(6000))


def test_coupon_expiring_during_overnight_stay(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제17조 예: 입차 시 유효해도 9월 11일 01시 출차에는 만료된다."""
    receipt = service.checkout(
        make_session(180, lot_id="HJ-02", entry_at=datetime(2026, 9, 10, 22), is_member=True),
        replace(coupon, valid_until=datetime(2026, 9, 10, 23, 59, 59)),
    )
    assert receipt.total == Money(8100)
    assert receipt.coupon is not None
    assert receipt.coupon.status is CouponStatus.EXPIRED


def test_grace_returns_coupon(
    service: CheckoutService, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제16조: 실제 주차 시간이 회차 이내이면 쿠폰을 반환한다."""
    receipt = service.checkout(make_session(15, lot_id="HJ-02"), coupon)
    assert receipt.grace_applied
    assert receipt.total == Money.zero()
    assert receipt.coupon is not None
    assert receipt.coupon.status is CouponStatus.UNUSED


def test_season_pass_returns_coupon(
    pricing_config: PricingConfig, make_session: SessionFactory, coupon: Coupon
) -> None:
    """제18조: 정기권 무료 출차는 쿠폰을 반환한다."""
    passes = FakeSeasonPassRepository(
        [SeasonPass("12가3456", "HJ-02", date(2026, 9, 1), date(2026, 9, 30))]
    )
    receipt = CheckoutService(pricing_config, passes).checkout(
        make_session(600, lot_id="HJ-02"), coupon
    )
    assert receipt.season_pass_applied
    assert receipt.total == Money.zero()
    assert receipt.coupon is not None
    assert receipt.coupon.status is CouponStatus.UNUSED
