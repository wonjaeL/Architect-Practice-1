"""CLI 통합 테스트(docs/api/cli.md). 실제 data/ 복사본으로 명령을 실행한다."""

from __future__ import annotations

import json
import runpy
import sys

import pytest

from parkfee.infrastructure.data_dir import DataDirectory
from parkfee.presentation.cli import main
from tests.conftest import REPO_ROOT

SAMPLE_CSV = str(REPO_ROOT / "data" / "samples" / "sessions_2026-09-01.csv")


def _calc_args(data_dir: DataDirectory, *extra: str) -> list[str]:
    return [
        "--data-dir",
        str(data_dir.root),
        "calc",
        "--lot",
        "HJ-01",
        "--plate",
        "12가3456",
        "--entry",
        "2026-09-01T09:00",
        "--exit",
        "2026-09-01T11:05",
        *extra,
    ]


def test_calc_text(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(_calc_args(data_dir, "--vehicle-type", "compact", "--member")) == 0
    assert "결제금액 : 4,400원" in capsys.readouterr().out


def test_calc_json(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(_calc_args(data_dir, "--format", "json")) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["total"] == 7000
    assert payload["coupon"] is None


def test_calc_season_pass_from_data_file(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    args = _calc_args(data_dir, "--format", "json")
    args[args.index("12가3456")] = "34나5678"
    assert main(args) == 0
    assert json.loads(capsys.readouterr().out)["season_pass"] is True


def test_batch_report(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--data-dir", str(data_dir.root), "batch", SAMPLE_CSV, "--format", "json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["total_sessions"] == 16
    assert payload["total_revenue"] == 79900


def test_coupon_show(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", "HJM-2609-0002"]) == 0
    assert "한결마트 무료 주차 120분" in capsys.readouterr().out


def test_data_dir_from_environment(
    data_dir: DataDirectory,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("PARKFEE_DATA_DIR", str(data_dir.root))
    assert main(["coupon", "show", "HJT-2609-0001", "--format", "json"]) == 0
    assert json.loads(capsys.readouterr().out)["lot_id"] == "HJ-01"


@pytest.mark.parametrize(
    ("replace", "code"),
    [(("HJ-01", "HJ-99"), "E1003"), (("2026-09-01T11:05", "11시"), "E1002")],
)
def test_input_errors_exit_with_3(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    replace: tuple[str, str],
    code: str,
) -> None:
    args = _calc_args(data_dir)
    args[args.index(replace[0])] = replace[1]
    assert main(args) == 3
    assert code in capsys.readouterr().err


def test_unknown_coupon_exits_with_3(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", "NOPE"]) == 3
    assert "E2001" in capsys.readouterr().err


@pytest.mark.parametrize("code", ["NOPE", ""])
def test_calc_unknown_coupon_matches_show_error(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str], code: str
) -> None:
    """없는 코드는 coupon show와 동일한 E2001 오류를 반환한다."""
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", code]) == 3
    expected = capsys.readouterr().err
    assert main(_calc_args(data_dir, "--coupon", code)) == 3
    output = capsys.readouterr()
    assert output.err == expected
    assert output.out == ""


@pytest.mark.parametrize(
    ("code", "status", "total"),
    [
        ("HJM-2609-0002", "applied", 27000),
        ("HJM-2609-0003", "applied", 29000),
        ("HJT-2609-0001", "unused", 30000),
        ("HJM-2608-0107", "expired", 30000),
    ],
)
def test_calc_coupon_from_data_file(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    code: str,
    status: str,
    total: int,
) -> None:
    """제12~17조: 실제 쿠폰 파일로 적용·반환·만료와 계산 순서를 확인한다."""
    args = _calc_args(data_dir, "--coupon", code, "--format", "json")
    args[args.index("HJ-01")] = "HJ-02"
    args[args.index("2026-09-01T09:00")] = "2026-09-15T09:00"
    args[args.index("2026-09-01T11:05")] = "2026-09-15T20:00"
    assert main(args) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["coupon"] == {"code": code, "status": status}
    assert payload["total"] == total


def test_calc_coupon_text(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    """제19조: 텍스트 영수증에 쿠폰 코드와 사용 결과를 표시한다."""
    assert main(_calc_args(data_dir, "--coupon", "HJT-2609-0001")) == 0
    text = capsys.readouterr().out
    assert "쿠폰     : HJT-2609-0001 (사용)" in text
    assert "결제금액 : 5,500원" in text


def test_calc_reads_coupon_from_selected_directory(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    """--data-dir의 쿠폰을 사용하며 원본 data/로 대체하지 않는다."""
    coupons = json.loads(data_dir.coupons.read_text(encoding="utf-8"))
    coupons[5]["code"] = "CUSTOM-CODE"
    data_dir.coupons.write_text(json.dumps(coupons), encoding="utf-8")
    assert main(_calc_args(data_dir, "--coupon", "CUSTOM-CODE", "--format", "json")) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["coupon"] == {"code": "CUSTOM-CODE", "status": "applied"}


def test_calc_without_coupon_does_not_require_coupon_file(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    data_dir.coupons.unlink()
    assert main(_calc_args(data_dir, "--format", "json")) == 0
    assert json.loads(capsys.readouterr().out)["coupon"] is None


def test_missing_data_dir_exits_with_4(capsys: pytest.CaptureFixture[str]) -> None:
    args = ["--data-dir", "/nonexistent", "calc", "--lot", "HJ-01", "--plate", "1가1111"]
    args += ["--entry", "2026-09-01T09:00", "--exit", "2026-09-01T10:00"]
    assert main(args) == 4
    assert "E3001" in capsys.readouterr().err


def test_version_option(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exit_info:
        main(["--version"])
    assert exit_info.value.code == 0
    assert "parkfee 1.6.0" in capsys.readouterr().out


def test_module_entry_point(
    data_dir: DataDirectory,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        ["parkfee", "--data-dir", str(data_dir.root), "coupon", "show", "HJM-2609-0001"],
    )
    with pytest.raises(SystemExit) as exit_info:
        runpy.run_module("parkfee", run_name="__main__")
    assert exit_info.value.code == 0
    assert "한결시네마" in capsys.readouterr().out
