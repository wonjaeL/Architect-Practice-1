from __future__ import annotations

from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.pricing.charge import create_charge_strategy
from parkfee.pricing.schedule import Schedule


class CouponPolicy:
    """쿠폰만 적용한 절사 전 요금(할인·감면 규정 제13~14조)."""

    def amount(self, coupon: Coupon, minutes: int, schedule: Schedule) -> Money:
        strategy = create_charge_strategy(schedule)
        if coupon.kind is CouponKind.TIME:
            # 실제 주차 시간으로 회차 판단을 마쳤으므로 회차를 다시 적용하지 않는다.
            return strategy.charge(max(0, minutes - coupon.value))
        return strategy.charge(minutes).minus(Money(coupon.value))
