from __future__ import annotations

# CLI 통합 테스트(docs/api/cli.md). 실제 data/ 복사본으로 명령을 실행한다.
import json
import runpy
import sys

import pytest

from parkfee.infrastructure.data_dir import DataDirectory
from parkfee.presentation.cli import main
from tests.conftest import REPO_ROOT

SAMPLE_CSV = str(REPO_ROOT / "data" / "samples" / "sessions_2026-09-01.csv")


def _calc_args(data_dir: DataDirectory, *extra: str) -> list[str]:
    return [
        "--data-dir",
        str(data_dir.root),
        "calc",
        "--lot",
        "HJ-01",
        "--plate",
        "12가3456",
        "--entry",
        "2026-09-01T09:00",
        "--exit",
        "2026-09-01T11:05",
        *extra,
    ]


def test_calc_text(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(_calc_args(data_dir, "--vehicle-type", "compact", "--member")) == 0
    assert "결제금액 : 4,400원" in capsys.readouterr().out


def test_calc_json(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(_calc_args(data_dir, "--format", "json")) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["total"] == 7000


def test_calc_season_pass_from_data_file(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    args = _calc_args(data_dir, "--format", "json")
    args[args.index("12가3456")] = "34나5678"
    assert main(args) == 0
    assert json.loads(capsys.readouterr().out)["season_pass"] is True


def test_batch_report(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--data-dir", str(data_dir.root), "batch", SAMPLE_CSV, "--format", "json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["total_sessions"] == 16
    assert payload["total_revenue"] == 79900


def test_coupon_show(data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]) -> None:
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", "HJM-2609-0002"]) == 0
    assert "한결마트 무료 주차 120분" in capsys.readouterr().out


def test_data_dir_from_environment(
    data_dir: DataDirectory,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setenv("PARKFEE_DATA_DIR", str(data_dir.root))
    assert main(["coupon", "show", "HJT-2609-0001", "--format", "json"]) == 0
    assert json.loads(capsys.readouterr().out)["lot_id"] == "HJ-01"


@pytest.mark.parametrize(
    ("replace", "code"),
    [(("HJ-01", "HJ-99"), "E1003"), (("2026-09-01T11:05", "11시"), "E1002")],
)
def test_input_errors_exit_with_3(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    replace: tuple[str, str],
    code: str,
) -> None:
    args = _calc_args(data_dir)
    args[args.index(replace[0])] = replace[1]
    assert main(args) == 3
    assert code in capsys.readouterr().err


def test_unknown_coupon_exits_with_3(
    data_dir: DataDirectory, capsys: pytest.CaptureFixture[str]
) -> None:
    assert main(["--data-dir", str(data_dir.root), "coupon", "show", "NOPE"]) == 3
    assert "E2001" in capsys.readouterr().err


def test_missing_data_dir_exits_with_4(capsys: pytest.CaptureFixture[str]) -> None:
    args = ["--data-dir", "/nonexistent", "calc", "--lot", "HJ-01", "--plate", "1가1111"]
    args += ["--entry", "2026-09-01T09:00", "--exit", "2026-09-01T10:00"]
    assert main(args) == 4
    assert "E3001" in capsys.readouterr().err


def test_version_option(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exit_info:
        main(["--version"])
    assert exit_info.value.code == 0
    assert "parkfee 1.6.0" in capsys.readouterr().out


def test_module_entry_point(
    data_dir: DataDirectory,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr(
        sys,
        "argv",
        ["parkfee", "--data-dir", str(data_dir.root), "coupon", "show", "HJM-2609-0001"],
    )
    with pytest.raises(SystemExit) as exit_info:
        runpy.run_module("parkfee", run_name="__main__")
    assert exit_info.value.code == 0
    assert "한결시네마" in capsys.readouterr().out


@pytest.mark.parametrize(
    ("code", "status", "label", "total"),
    [
        ("HJT-2609-0001", "applied", "사용", 5000),
        ("HJM-2609-0001", "unused", "반환", 6500),
        ("HJT-2609-0002", "expired", "만료", 6500),
    ],
)
@pytest.mark.parametrize("output_format", ["text", "json"])
def test_calc_coupon_receipt(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    code: str,
    status: str,
    label: str,
    total: int,
    output_format: str,
) -> None:
    """할인·감면 규정 제12·13·17·19조: 지정한 데이터 파일과 처리 결과 출력."""
    original = data_dir.coupons.read_bytes()
    args = _calc_args(
        data_dir,
        "--entry",
        "2026-09-16T09:00",
        "--exit",
        "2026-09-16T11:00",
        "--coupon",
        code,
        "--format",
        output_format,
    )
    assert main(args) == 0
    output = capsys.readouterr().out
    if output_format == "json":
        payload = json.loads(output)
        assert payload["coupon"] == {"code": code, "status": status}
        assert payload["total"] == total
        assert payload["charge"] == 6500
        assert payload["parked_minutes"] == 120
        assert payload["vat"]["supply"] + payload["vat"]["tax"] == total
    else:
        assert f"쿠폰     : {code} ({label})" in output
        assert f"결제금액 : {total:,}원" in output
    assert data_dir.coupons.read_bytes() == original


def test_calc_without_coupon_does_not_read_coupon_file(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """CLI 명세: 쿠폰 미지정은 null이고 기존 정산은 쿠폰 파일 없이도 동작한다."""
    data_dir.coupons.unlink()
    assert main(_calc_args(data_dir, "--format", "json")) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["coupon"] is None
    assert payload["total"] == 7000


@pytest.mark.parametrize("minutes", [5, 120])
def test_calc_unknown_coupon_exits_with_3(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    minutes: int,
) -> None:
    """ISSUE-142: 없는 코드는 무료 출차라도 coupon show와 같은 E2001 오류이다."""
    exit_at = "2026-09-01T09:05" if minutes == 5 else "2026-09-01T11:00"
    assert main(_calc_args(data_dir, "--exit", exit_at, "--coupon", "NOPE")) == 3
    output = capsys.readouterr()
    assert output.out == ""
    assert "[E2001] 쿠폰을 찾을 수 없습니다: NOPE" in output.err


@pytest.mark.parametrize("is_missing", [False, True])
def test_calc_coupon_data_error_exits_with_4(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    is_missing: bool,
) -> None:
    """로깅·에러 처리 규정: 요청한 쿠폰의 데이터 파일 오류는 E3001이다."""
    if is_missing:
        data_dir.coupons.unlink()
    else:
        data_dir.coupons.write_text("{broken", encoding="utf-8")
    assert main(_calc_args(data_dir, "--coupon", "HJT-2609-0001")) == 4
    assert "E3001" in capsys.readouterr().err


@pytest.mark.parametrize("plate", ["12가3456", "34나5678"])
def test_free_coupon_receipt_from_cli(
    data_dir: DataDirectory,
    capsys: pytest.CaptureFixture[str],
    plate: str,
) -> None:
    """할인·감면 규정 제16·18·19조: 회차·정기권 무료 영수증에도 쿠폰 반환 표시."""
    exit_at = "2026-09-01T09:05" if plate == "12가3456" else "2026-09-01T11:00"
    assert (
        main(
            _calc_args(
                data_dir,
                "--plate",
                plate,
                "--exit",
                exit_at,
                "--coupon",
                "HJT-2609-0001",
            )
        )
        == 0
    )
    output = capsys.readouterr().out
    assert "쿠폰     : HJT-2609-0001 (반환)" in output
    assert "결제금액 : 0원" in output
