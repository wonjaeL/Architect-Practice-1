# AGENTS.md

이 저장소에서 작업하는 AI 에이전트의 작업 지침입니다. 필요한 문서는 아래 목록에서 골라 그때 읽으세요.

## 프로젝트
- parkfee: 한결파킹 주차요금 정산 엔진. Python 3.10 이상, 표준 라이브러리만 사용.
- 요금·할인 계산의 기준은 운영 규정 문서(docs/policy)다. 규정이 회의록·FAQ·변경 이력보다 우선한다.

## 기본 명령
- 테스트: `python tools/test_summary.py` (전체 테스트를 실행하고 요약을 확인한다. 실패하면 표시된 로그에서 실패한 테스트 주변만 조회한다.)
- 린트: `make lint`, 타입 검사: `make typecheck`
- 변경 후에는 항상 전체 테스트를 다시 실행한다. 통과하면 상세 성공 로그는 다시 읽지 않는다.

## 코드 지도
| 위치 | 내용 |
|---|---|
| src/parkfee/domain/ | 엔터티·값 객체: Money, ParkingSession, Coupon, SeasonPass, Receipt, 오류 코드 |
| src/parkfee/pricing/ | 요금 계산 방식(ChargeStrategy), 할인 정책(DiscountPolicy), 할인 파이프라인, 절사·부가세 |
| src/parkfee/application/ | 출차 정산(CheckoutService), 일일 정산 |
| src/parkfee/infrastructure/ | JSON·CSV 저장소 |
| src/parkfee/presentation/ | CLI(cli.py), 출력 형식(formatters.py) |
| tests/unit/, tests/integration/ | 단위 테스트, CLI 통합 테스트 |

## 문서 목록 (필요할 때 해당 문서만 읽을 것)
| 문서 | 언제 읽나 |
|---|---|
| docs/policy/fee-policy.md | 요금 계산, 회차, 일 최대 요금, 절사, 부가세 |
| docs/policy/discount-policy.md | 감면, 멤버십, 제휴 쿠폰 적용 규칙 (쿠폰은 제5장) |
| docs/policy/season-pass-policy.md | 정기권 |
| docs/architecture/overview.md | 계층 구조, 의존 규칙, 새 정책·모듈 추가 방법 |
| docs/architecture/data-model.md | 데이터 파일(JSON·CSV) 형식 |
| docs/api/cli.md | CLI 옵션과 JSON 출력 형식 |
| docs/development/coding-convention.md | 코드 작성 규칙 |
| docs/development/testing-strategy.md | 테스트 작성 기준 |
| docs/development/logging-and-errors.md | 로그 규칙, 오류 코드 |
| docs/README.md | 그 밖의 모든 문서 목록 |

## 꼭 지킬 것
- 금액은 Money 값 객체로만 다룬다.
- 규정 수치를 코드에 상수로 쓰지 않는다 (data/fee_schedules.json에서 읽는다).
- 로그에 차량번호 전체를 남기지 않는다.

## 쿠폰 작업의 문서 조회 순서
- `docs/policy/discount-policy.md` 제5장을 먼저 확인한다. 요금 계산은 `docs/policy/fee-policy.md`의 해당 조항과 대조한다.
- CLI 옵션과 출력은 `docs/api/cli.md`, 데이터 필드가 불명확하면 `docs/architecture/data-model.md`의 해당 부분을 확인한다.
- 코드와 테스트는 관련 함수부터 읽고, 필요한 의존성만 확장한다. 문서를 전부 한꺼번에 출력하지 않는다.
- 확정 운영 규정으로 해결되지 않는 의문이 있을 때만 나머지 문서 목록을 탐색한다.
