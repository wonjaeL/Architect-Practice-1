"""쿠폰만 적용하는 요금 정책(할인·감면 규정 제13~14조)."""

from __future__ import annotations

from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.pricing.charge import create_charge_strategy
from parkfee.pricing.schedule import Schedule


class CouponPolicy:
    """시간 쿠폰은 요금 계산 전, 금액 쿠폰은 일 최대 요금 적용 후 차감한다."""

    def calculate(self, coupon: Coupon, minutes: int, schedule: Schedule) -> Money:
        strategy = create_charge_strategy(schedule)
        if coupon.kind is CouponKind.TIME:
            return strategy.charge(max(0, minutes - coupon.value))
        return strategy.charge(minutes).minus(Money(coupon.value))
