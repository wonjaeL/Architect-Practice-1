from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime, timedelta

import pytest

from parkfee.application.checkout import CheckoutService
from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.domain.receipt import CouponResult, CouponStatus, DiscountKind
from parkfee.domain.season_pass import SeasonPass
from parkfee.domain.vehicle import VehicleType
from parkfee.pricing.schedule import PricingConfig
from tests.conftest import FakeSeasonPassRepository, SessionFactory

COUPON = Coupon(
    code="TEST-COUPON",
    kind=CouponKind.TIME,
    value=60,
    lot_id="HJ-02",
    partner="제휴 매장",
    valid_from=datetime(2026, 9, 1),
    valid_until=datetime(2026, 9, 30, 23, 59, 59),
)
ENTRY = datetime(2026, 9, 15, 9)


@pytest.fixture
def service(pricing_config: PricingConfig) -> CheckoutService:
    return CheckoutService(pricing_config, FakeSeasonPassRepository())


@pytest.mark.parametrize(
    ("minutes", "value", "expected"),
    [
        (660, 120, 27000),
        (1500, 120, 30000),
        (120, 60, 3000),
        (120, 120, 0),
        (120, 180, 0),
        (61, 60, 1500),
        (75, 60, 1500),
        (90, 60, 1500),
        (91, 60, 2000),
        (100, 60, 2000),
        (101, 60, 2500),
    ],
)
def test_time_coupon_before_charge_and_daily_max(
    service: CheckoutService,
    make_session: SessionFactory,
    minutes: int,
    value: int,
    expected: int,
) -> None:
    """제13·16조: 시간을 먼저 차감하되 남은 시간에 회차를 재적용하지 않는다."""
    session = make_session(minutes, lot_id="HJ-02", entry_at=ENTRY)
    original = service.checkout(session)
    receipt = service.checkout(session, replace(COUPON, value=value))
    assert receipt.total == Money(expected)
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.APPLIED)
    assert receipt.charge == original.charge
    assert receipt.parked_minutes == minutes
    assert not receipt.grace_applied
    assert receipt.discount_total == original.charge.minus(Money(expected))
    assert [discount.kind for discount in receipt.discounts] == [DiscountKind.COUPON]
    assert receipt.vat_supply + receipt.vat_tax == receipt.total


@pytest.mark.parametrize(("minutes", "expected"), [(1440, 6000), (1441, 6000), (1501, 12000)])
def test_time_coupon_daily_flat(
    service: CheckoutService,
    make_session: SessionFactory,
    minutes: int,
    expected: int,
) -> None:
    """제13조: 정액제도 차감 후 남은 시간으로 계산하고 동액이면 반환한다."""
    session = make_session(minutes, lot_id="HJ-03", entry_at=ENTRY)
    receipt = service.checkout(session, replace(COUPON, lot_id="HJ-03"))
    assert receipt.total == Money(expected)
    status = CouponStatus.APPLIED if minutes == 1441 else CouponStatus.UNUSED
    assert receipt.coupon == CouponResult(COUPON.code, status)


@pytest.mark.parametrize(("minutes", "value", "expected"), [(660, 1000, 29000), (120, 9000, 0)])
def test_amount_coupon_after_daily_max_with_zero_floor(
    service: CheckoutService,
    make_session: SessionFactory,
    minutes: int,
    value: int,
    expected: int,
) -> None:
    """제14조: 일 최대 요금 적용 후 금액 차감, 0원 하한."""
    coupon = replace(COUPON, kind=CouponKind.AMOUNT, value=value)
    receipt = service.checkout(make_session(minutes, lot_id="HJ-02", entry_at=ENTRY), coupon)
    assert receipt.total == Money(expected)
    assert receipt.coupon == CouponResult(coupon.code, CouponStatus.APPLIED)


def test_reduction_and_membership_win_without_stacking(
    service: CheckoutService,
    make_session: SessionFactory,
) -> None:
    """제15조 예시: 5,000원과 3,700원 중 일반 할인 선택, 쿠폰 반환."""
    session = make_session(
        120, lot_id="HJ-02", entry_at=ENTRY, vehicle_type=VehicleType.COMPACT, is_member=True
    )
    receipt = service.checkout(session, replace(COUPON, kind=CouponKind.AMOUNT, value=1000))
    assert receipt.total == Money(3700)
    assert receipt.discounts == service.checkout(session).discounts
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.UNUSED)


def test_coupon_wins_without_membership(
    service: CheckoutService,
    make_session: SessionFactory,
) -> None:
    """제15조 예시: 3,000원과 5,400원 중 쿠폰 선택, 멤버십 중복 금지."""
    receipt = service.checkout(
        make_session(120, lot_id="HJ-02", entry_at=ENTRY, is_member=True), COUPON
    )
    assert receipt.total == Money(3000)
    assert [discount.kind for discount in receipt.discounts] == [DiscountKind.COUPON]
    assert (receipt.vat_supply, receipt.vat_tax) == (Money(2727), Money(273))


@pytest.mark.parametrize("value", [2220, 2250])
def test_tie_after_rounding_returns_coupon(
    service: CheckoutService,
    make_session: SessionFactory,
    value: int,
) -> None:
    """제15조: 3,780원과 3,750원도 절사 후 3,700원 동액이므로 반환."""
    session = make_session(
        120, lot_id="HJ-02", entry_at=ENTRY, vehicle_type=VehicleType.COMPACT, is_member=True
    )
    receipt = service.checkout(session, replace(COUPON, kind=CouponKind.AMOUNT, value=value))
    assert receipt.total == Money(3700)
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.UNUSED)


@pytest.mark.parametrize("value", [0, 1])
def test_no_saving_returns_coupon(
    service: CheckoutService,
    make_session: SessionFactory,
    value: int,
) -> None:
    """제15조: 시간 쿠폰이 요금 단위를 줄이지 못하면 반환."""
    receipt = service.checkout(
        make_session(120, lot_id="HJ-02", entry_at=ENTRY), replace(COUPON, value=value)
    )
    assert receipt.total == Money(6000)
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.UNUSED)


@pytest.mark.parametrize(
    ("offset", "status"),
    [
        (-1, CouponStatus.UNUSED),
        (0, CouponStatus.APPLIED),
        (3600, CouponStatus.APPLIED),
        (3601, CouponStatus.EXPIRED),
    ],
)
def test_validity_uses_exit_time_with_inclusive_boundaries(
    service: CheckoutService,
    make_session: SessionFactory,
    offset: int,
    status: CouponStatus,
) -> None:
    """제17조: 출차 기준으로 시작 전·양쪽 경계·종료 후를 판정한다."""
    coupon = replace(COUPON, valid_from=ENTRY, valid_until=ENTRY + timedelta(hours=1))
    exit_at = ENTRY + timedelta(seconds=offset)
    session = make_session(120, lot_id="HJ-02", entry_at=exit_at - timedelta(hours=2))
    receipt = service.checkout(session, coupon)
    assert receipt.coupon == CouponResult(coupon.code, status)
    assert receipt.total == Money(3000 if status is CouponStatus.APPLIED else 6000)


def test_coupon_expires_during_overnight_parking(
    service: CheckoutService,
    make_session: SessionFactory,
) -> None:
    """제17조 예시: 입차 시 유효해도 자정을 넘어 출차하면 만료."""
    coupon = replace(COUPON, valid_until=datetime(2026, 9, 10, 23, 59, 59))
    session = make_session(180, lot_id="HJ-02", entry_at=datetime(2026, 9, 10, 22))
    receipt = service.checkout(session, coupon)
    assert receipt.coupon == CouponResult(coupon.code, CouponStatus.EXPIRED)
    assert receipt.total == service.checkout(session).total


def test_other_lot_returns_coupon(service: CheckoutService, make_session: SessionFactory) -> None:
    """제12조: 발급 주차장이 다르면 반환."""
    session = make_session(120, entry_at=ENTRY)
    receipt = service.checkout(session, COUPON)
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.UNUSED)
    assert receipt.total == service.checkout(session).total


@pytest.mark.parametrize("minutes", [0, 15])
def test_grace_returns_coupon(
    service: CheckoutService,
    make_session: SessionFactory,
    minutes: int,
) -> None:
    """제16조: 실제 주차 시간이 회차 이내이면 쿠폰 반환."""
    receipt = service.checkout(make_session(minutes, lot_id="HJ-02", entry_at=ENTRY), COUPON)
    assert receipt.grace_applied
    assert receipt.total == Money.zero()
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.UNUSED)


def test_season_pass_returns_coupon(
    pricing_config: PricingConfig,
    make_session: SessionFactory,
) -> None:
    """제18조: 정기권 무료 출차는 쿠폰 반환."""
    passes = FakeSeasonPassRepository(
        [SeasonPass("12가3456", "HJ-02", date(2026, 9, 1), date(2026, 9, 30))]
    )
    receipt = CheckoutService(pricing_config, passes).checkout(
        make_session(120, lot_id="HJ-02", entry_at=ENTRY), COUPON
    )
    assert receipt.season_pass_applied
    assert receipt.total == Money.zero()
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.UNUSED)


def test_coupon_uses_configured_rounding_unit(
    pricing_config: PricingConfig,
    make_session: SessionFactory,
) -> None:
    """제15조: 비교 시 절사 단위는 설정을 따른다."""
    service = CheckoutService(
        replace(pricing_config, rounding_unit=500), FakeSeasonPassRepository()
    )
    receipt = service.checkout(
        make_session(120, lot_id="HJ-02", entry_at=ENTRY, is_member=True),
        replace(COUPON, kind=CouponKind.AMOUNT, value=750),
    )
    assert receipt.total == Money(5000)
    assert receipt.coupon == CouponResult(COUPON.code, CouponStatus.UNUSED)
