from __future__ import annotations

from parkfee.domain.coupon import Coupon, CouponKind
from parkfee.domain.money import Money
from parkfee.pricing.charge import ChargeStrategy


class CouponChargePolicy:
    """쿠폰만 적용한 절사 전 금액을 계산한다(할인·감면 규정 제13·14조)."""

    def charge(self, coupon: Coupon, minutes: int, strategy: ChargeStrategy) -> Money:
        if coupon.kind is CouponKind.TIME:
            return strategy.charge(max(0, minutes - coupon.value))
        return strategy.charge(minutes).minus(Money(coupon.value))
