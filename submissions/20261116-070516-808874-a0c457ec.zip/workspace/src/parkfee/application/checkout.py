from __future__ import annotations

import logging
from dataclasses import replace

from parkfee.application.ports import SeasonPassRepository
from parkfee.domain.coupon import Coupon
from parkfee.domain.money import Money
from parkfee.domain.plate import mask_plate
from parkfee.domain.receipt import (
    AppliedDiscount,
    CouponResult,
    CouponStatus,
    DiscountKind,
    Receipt,
)
from parkfee.domain.session import ParkingSession
from parkfee.pricing.charge import create_charge_strategy
from parkfee.pricing.coupon import CouponChargePolicy
from parkfee.pricing.discount import DiscountContext, MembershipPolicy, ReductionPolicy
from parkfee.pricing.pipeline import DiscountPipeline
from parkfee.pricing.rounding import FloorRounding, split_vat
from parkfee.pricing.schedule import LotPolicy, PricingConfig

logger = logging.getLogger(__name__)


class CheckoutService:
    """출차 1건을 정산한다.

    순서: 정기권 확인 → 회차 확인 → 요금 계산 → 할인 → 절사 → 부가세 분리
    (요금 규정 제9조).
    """

    def __init__(
        self,
        config: PricingConfig,
        season_passes: SeasonPassRepository,
        pipeline: DiscountPipeline | None = None,
    ) -> None:
        self._config = config
        self._season_passes = season_passes
        self._pipeline = pipeline or DiscountPipeline(
            [ReductionPolicy(config.reduction_rates), MembershipPolicy()]
        )
        self._rounding = FloorRounding(config.rounding_unit)

    def checkout(self, session: ParkingSession, coupon: Coupon | None = None) -> Receipt:
        lot = self._config.lot(session.lot_id)
        minutes = session.parked_minutes
        logger.debug(
            "정산 시작 lot=%s plate=%s minutes=%d",
            lot.lot_id,
            mask_plate(session.plate),
            minutes,
        )
        if self._has_valid_season_pass(session):
            logger.debug("정기권 차량: 요금 0원")
            receipt = self._free_receipt(session, lot, minutes, season_pass=True)
        elif minutes <= lot.grace_minutes:
            logger.debug("회차 시간 %d분 이내: 요금 0원", lot.grace_minutes)
            receipt = self._free_receipt(session, lot, minutes, grace=True)
        else:
            receipt = self._charged_receipt(session, lot, minutes)
        if coupon is None:
            return receipt
        return self._with_coupon(receipt, coupon, lot)

    def _with_coupon(self, receipt: Receipt, coupon: Coupon, lot: LotPolicy) -> Receipt:
        """무료 출차는 반환, 그 외에는 출차 시각으로 검증(할인·감면 제12·16~18조)."""
        receipt = replace(receipt, coupon=CouponResult(coupon.code, CouponStatus.UNUSED))
        if receipt.season_pass_applied or receipt.grace_applied:
            return receipt
        if receipt.session.exit_at > coupon.valid_until:
            return replace(receipt, coupon=CouponResult(coupon.code, CouponStatus.EXPIRED))
        if coupon.lot_id != lot.lot_id or not coupon.is_valid_at(receipt.session.exit_at):
            return receipt
        return self._choose_coupon(receipt, coupon, lot)

    def _choose_coupon(self, receipt: Receipt, coupon: Coupon, lot: LotPolicy) -> Receipt:
        """두 경로를 절사한 뒤 비교하고 동액이면 반환한다(할인·감면 규정 제15조)."""
        amount = CouponChargePolicy().charge(
            coupon, receipt.parked_minutes, create_charge_strategy(lot.schedule)
        )
        total = self._rounding.apply(amount)
        logger.debug("쿠폰 적용 시 %s (절사 전 %s), 일반 할인 시 %s", total, amount, receipt.total)
        if total >= receipt.total:
            return receipt
        supply, tax = split_vat(total)
        discount = AppliedDiscount(
            DiscountKind.COUPON, coupon.describe(), receipt.charge.minus(amount)
        )
        return replace(
            receipt,
            discounts=(discount,),
            total=total,
            vat_supply=supply,
            vat_tax=tax,
            coupon=CouponResult(coupon.code, CouponStatus.APPLIED),
        )

    def _has_valid_season_pass(self, session: ParkingSession) -> bool:
        return any(
            season_pass.covers(session)
            for season_pass in self._season_passes.find_by_plate(session.plate)
        )

    def _charged_receipt(self, session: ParkingSession, lot: LotPolicy, minutes: int) -> Receipt:
        charge = create_charge_strategy(lot.schedule).charge(minutes)
        result = self._pipeline.run(charge, DiscountContext(session=session, lot=lot))
        total = self._rounding.apply(result.amount)
        supply, tax = split_vat(total)
        logger.debug("요금 %s, 할인 후 %s, 결제 %s", charge, result.amount, total)
        return Receipt(
            session=session,
            lot_name=lot.name,
            parked_minutes=minutes,
            charge=charge,
            discounts=result.applied,
            total=total,
            vat_supply=supply,
            vat_tax=tax,
        )

    @staticmethod
    def _free_receipt(
        session: ParkingSession,
        lot: LotPolicy,
        minutes: int,
        *,
        grace: bool = False,
        season_pass: bool = False,
    ) -> Receipt:
        zero = Money.zero()
        return Receipt(
            session=session,
            lot_name=lot.name,
            parked_minutes=minutes,
            charge=zero,
            discounts=(),
            total=zero,
            vat_supply=zero,
            vat_tax=zero,
            grace_applied=grace,
            season_pass_applied=season_pass,
        )
